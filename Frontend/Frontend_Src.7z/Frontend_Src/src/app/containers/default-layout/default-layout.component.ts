import { Component, OnDestroy, Inject } from '@angular/core';
import { DOCUMENT } from '@angular/common';
import { navItems } from '../../_nav';
import { DefaultService } from './default-layout.service';
import { Router } from '@angular/router';


@Component({
  selector: 'app-dashboard',
  templateUrl: './default-layout.component.html'
})
export class DefaultLayoutComponent implements OnDestroy {
  public navItems = navItems;
  public sidebarMinimized = true;
  private changes: MutationObserver;
  public element: HTMLElement;
  error: any;
  childrenList: any[] = [];
  flag: boolean = false;

  constructor(private router: Router, private defaultService: DefaultService, @Inject(DOCUMENT) _document?: any) {
    this.changes = new MutationObserver((mutations) => {
      this.sidebarMinimized = _document.body.classList.contains('sidebar-minimized');
    });
    this.element = _document.body;
    this.changes.observe(<Element>this.element, {
      attributes: true,
      attributeFilter: ['class']
    });
    
    this.navItems.length = 0;
    this.navItems.push(
      {
        name: 'Ticket Management',
        url: '/management',
        icon: 'fa fa-list'
      },
      {
        name: 'Ticket Booking',
        url: '/booking',
        icon: 'fa fa-ticket',
      },
      
      // {
      //   name: 'Page 3',
      //   url: '/reelscontest',
      //   icon: 'fa fa-instagram'
      // }
    )

  }


  public onLogOut(e: any) {
    localStorage.clear();
    this.router.navigate(['/']);
  }

  ngOnDestroy(): void {
    this.changes.disconnect();
  }
}
