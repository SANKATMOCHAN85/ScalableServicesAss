import { Component, OnInit, ViewChild } from '@angular/core';
import { ManagementService } from './management.service';
import { Router } from '@angular/router';
import { DatePipe } from '@angular/common';
import { ModalDirective } from 'ngx-bootstrap/modal';
import { isNullOrUndefined } from 'util';

@Component({
  templateUrl: 'management.component.html',
  styleUrls: ['./management.component.scss']
})

export class ManagementComponent implements OnInit {

  error: any;
  currUserId: any;
  currUserName: any;
  ticketList: any[] = [];

  constructor(private router: Router, private service: ManagementService) {
    if (JSON.parse(localStorage.getItem('userCredentials'))) {
      var x = JSON.parse(localStorage.getItem('userCredentials'));
      this.currUserId = x.userId;
      this.currUserName = x.userName;
      this.GetAllData();
    }
    else {
      alert("An error has occurred. Please login again.");
      this.router.navigate(['']);
    }
  }

  public GetAllData() {
    this.service.getAll(this.currUserId)
      .subscribe(
        (data: any) => {
          setTimeout(() => {
            console.log(data)
            for (let index = 0; index < data.length; index++) {
              this.ticketList.push(
                {
                  From: data[index].From,
                  destination: data[index].destination,
                  passengers: data[index].passengers,
                  vehicleName: data[index].vehicleName,
                  ticketNumber: data[index].ticketNumber,
                  dateOfBooking: data[index].dateOfBooking,
                  dateOfTravel: data[index].dateOfTravel,
                  userId: data[index].userId
                  // From: data.From,
                  // destination: data.destination,
                  // passengers: data.passengers,
                  // vehicleName: data.vehicleName,
                  // ticketNumber: data.ticketNumber,
                  // dateOfBooking: data.dateOfBooking,
                  // dateOfTravel: data.dateOfTravel,
                  // userId: data.userId
                }
              );
            }
            console.log(this.ticketList)

          }, 1000);
        }, // success path
        error => this.error = error // error path
      );
  }

  ngOnInit(): void {

  }
}
