import { Component, OnInit, Input } from '@angular/core';
import { Router } from '@angular/router';
import { RegisterService } from './register.service';
import { navItems } from '../../_nav';

export interface RegisterData {
  Name: string;
  Age: string;
  Address: string;
  Email: string;
  Phone: string;
  Password: string;
}

@Component({
  selector: 'app-dashboard',
  styleUrls: ['./register.component.scss'],
  templateUrl: 'register.component.html'
})

export class RegisterComponent implements OnInit {
  public navItems = navItems;
  error: any;
  userName: string;
  userAge: string;
  userAddress: string;
  userEmail: string;
  userPhone: string;
  userPassword: string;
  isLoading: boolean = false;

  constructor(public router: Router, private loginServie: RegisterService) { }

  public loginClickEvent(e: any): void {
    this.register();
  }

  public setupRegisterData(): RegisterData {
    var nodeInput: RegisterData = {
      Name: this.userName,
      Age: this.userAge,
      Address: this.userAddress,
      Email: this.userEmail,
      Phone: this.userPhone,
      Password: this.userPassword
    }
    return nodeInput;
  }

  public register(): void {
    var nodeData = this.setupRegisterData();
    this.loginServie.register(nodeData)
      .subscribe(
        (data: any) => {
          setTimeout(() => {
            console.log(data);
            if (data.status == 1) {
              this.router.navigate(['']);
            }
          }, 1000);
        }, // success path
        error => this.error = error // error path
      );
  }

  ngOnInit() { }
}
