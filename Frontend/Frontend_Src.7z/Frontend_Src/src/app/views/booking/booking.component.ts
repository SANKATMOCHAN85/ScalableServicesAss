import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { getUrlScheme } from '@angular/compiler';
import { BookingService } from './booking.service';

export interface BookingData {
  From: String,
  destination: String,
  dateOfBooking: String,
  dateOfTravel: String,
  passengers: String,
  vehicleName: String,
  ticketNumber: String,
  userId: number
}


@Component({
  templateUrl: 'booking.component.html',
  styleUrls: ['./booking.component.scss'],
  encapsulation: ViewEncapsulation.Emulated
})
export class BookingComponent implements OnInit {

  passName: String;
  passAge: String;
  passEmail: boolean;
  passPhone: any;
  travelDate: string;
  bookDate: string;
  fromLocation: string;
  toLocation: string;
  vehType: string;
  vehNumber: string;
  currUserId: any;
  currUserName: any;
  error: any;

  constructor(private router: Router, private bookingService: BookingService) {
    if (JSON.parse(localStorage.getItem('userCredentials'))) {
      var x = JSON.parse(localStorage.getItem('userCredentials'));
      this.currUserId = x.userId;
      this.currUserName = x.userName;
    }
    else {
      alert("An error has occurred. Please login again.");
      this.router.navigate(['']);
    }
  }

  public bookClick(e: any) {
    this.bookTicket();
  }

  public setupBookingData(): BookingData {
    var nodeInput: BookingData = {
      From: this.fromLocation,
      destination: this.toLocation,
      dateOfBooking: this.bookDate,
      dateOfTravel: this.travelDate,
      passengers: this.passName,
      vehicleName: this.vehNumber,
      ticketNumber: "",
      userId: this.currUserId
    }
    return nodeInput;
  }

  public bookTicket(): void {
    var nodeData = this.setupBookingData();
    this.bookingService.booking(nodeData)
      .subscribe(
        (data: any) => {
          setTimeout(() => {
            console.log(data);
            this.router.navigate(['/management']);
          }, 1000);
        }, // success path
        error => this.error = error // error path
      );
  }

  public cancelClick(e: any) {
    this.router.navigate(['/management']);
  }

  ngOnInit(): void {

  }
}
