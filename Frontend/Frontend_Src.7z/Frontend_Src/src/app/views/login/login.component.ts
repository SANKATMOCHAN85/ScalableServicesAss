import { Component, OnInit, Input } from '@angular/core';
import { Router } from '@angular/router';
import { LoginService } from './login.service';
import { navItems } from '../../_nav';

export interface LoginData {
  Email: string;
  Password: string;
}

@Component({
  selector: 'app-dashboard',
  styleUrls: ['./login.component.scss'],
  templateUrl: 'login.component.html'
})

export class LoginComponent implements OnInit {
  public navItems = navItems;
  error: any;
  userEmail: string;
  userPassword: string;
  status: string;
  isLoading: boolean = false;

  constructor(public router: Router, private loginServie: LoginService) { }

  public loginClickEvent(e: any): void {
    this.status = "";
    this.login();
  }

  public registerClick(e: any): void {
    this.router.navigate(['/register']);
  }

  public setupLoginData(): LoginData {
    var nodeInput: LoginData = {
      Email: this.userEmail,
      Password: this.userPassword
    }
    return nodeInput;
  }

  public login(): void {
    var nodeData = this.setupLoginData();
    this.loginServie.login(nodeData)
      .subscribe(
        (data: any) => {
          setTimeout(() => {
            console.log(data);
            if (data.status == 1) {
              localStorage.setItem('userCredentials', JSON.stringify({ userId:data.data.id, userName: data.data.name }));
              this.router.navigate(['/booking']);
            } else {
              this.status = "Invalid Credentials. Try Again."
            }
          }, 1000);
        }, // success path
        error => this.error = error // error path
      );
  }

  ngOnInit() { }
}
