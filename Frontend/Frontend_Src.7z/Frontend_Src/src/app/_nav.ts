interface NavAttributes {
  [propName: string]: any;
}
interface NavWrapper {
  attributes: NavAttributes;
  element: string;
}
interface NavBadge {
  text: string;
  variant: string;
}
interface NavLabel {
  class?: string;
  variant: string;
}

export interface NavData {
  name?: string;
  url?: string;
  icon?: string;
  badge?: NavBadge;
  title?: boolean;
  children?: NavData[];
  variant?: string;
  attributes?: NavAttributes;
  divider?: boolean;
  class?: string;
  label?: NavLabel;
  wrapper?: NavWrapper;
  Key?: number;
}

export const navItems: NavData[] = [
  // {
  //   name: 'User Management',
  //   url: '/UserManagement',
  //   icon: 'icon-user',
  // },
  // {
  //   name: 'Client Management',
  //   url: '/ClientManagement',
  //   icon: 'icon-briefcase'
  // },
  // // {
  // //   name: 'Role Management',
  // //   url: '/customer',
  // //   icon: 'icon-wrench'
  // // },
  // // {
  // //   name: 'Badge settings',
  // //   url: '/customer',
  // //   icon: 'icon-badge'
  // // },
  // // {
  // //   name: 'Votes and feedback',
  // //   url: '/customer',
  // //   icon: 'icon-feed'
  // // },
  // {
  //   divider: true
  // },
  // {
  //   divider: true
  // },
  // {
  //   divider: true
  // },
  // {
  //   name: 'Hackathons',
  //   url: '/hackathonTabs',
  //   icon: 'icon-screen-desktop',
  //   children: []
  // },
  // // {
  // //   name: 'Hackathon entries',
  // //   url: '/customer',
  // //   icon: 'icon-paper-clip'
  // // },
  // // {
  // //   name: 'Published Entries(Employee site )',
  // //   url: '/customer',
  // //   icon: 'icon-list'
  // // },
  // // {
  // //   name: 'Entry Evaluation',
  // //   url: '/customer',
  // //   icon: 'icon-folder'
  // // },
  // // {
  // //   name: 'Published Projects(Client site )',
  // //   url: '/customer',
  // //   icon: 'icon-docs'
  // // },
  // {
  //   divider: true
  // },
  // {
  //   divider: true
  // },
  // {
  //   divider: true
  // },
  // {
  //   divider: true
  // },
  // {
  //   divider: true
  // },
  // {
  //   name: 'Rules & Regulations',
  //   url: '/customer',
  //   icon: 'icon-drawer'
  // },
  // {
  //   name: 'FAQs',
  //   url: '/customer',
  //   icon: 'icon-question'
  // },
  // {
  //   name: 'Support',
  //   url: '/customer',
  //   icon: 'icon-support'
  // },
];
